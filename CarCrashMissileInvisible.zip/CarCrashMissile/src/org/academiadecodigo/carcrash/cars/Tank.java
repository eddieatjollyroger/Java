package org.academiadecodigo.carcrash.cars;

import org.academiadecodigo.carcrash.field.Field;

public class Tank extends Car {
    private int counter = 0;

    private Missile[] missile;
    public Tank(String name) {
        this.name = name;
    }

    public Tank() {

    }
    public Missile[] summonMissile(){
        Missile[] missile = new Missile[1];
        missile[0] = new Missile("Missile");
        return missile;
    }
@Override
    public void shootMissile(Missile[] missile) {
        missile[0].getPos().setRow(getPos().getRow()+2);
        missile[0].getPos().setCol(getPos().getCol()+2);
        missile[0].setDirection(getDirection());
        missile[0].moveCars(1);
        System.out.println("Missil launched");
        Field.draw(missile);

    };

    @Override
    public void moveCars(int speed) {
        if (counter > 3) {
            shootMissile(summonMissile());
            super.moveCars(speed);
        counter = 0;
        }
        super.moveCars(speed);
        counter++;

    }

    @Override
    public void compareCars(Car[] cars) {

        for (int j = 0; j < cars.length; j++) {
            for (int i = 0; i < cars.length; i++) {
                if ((cars[i].getPos().getRow() == cars[j].getPos().getRow()) &&
                        (cars[i].getPos().getCol() == cars[j].getPos().getCol()) &&
                        (j != i) &&
                        cars[i].getName() == "Tank" &&
                        cars[j].getName() == "Tank") {
                    cars[i].setCrashed(true);
                    cars[j].setCrashed(true);
                } else if ((cars[i].getPos().getRow() == cars[j].getPos().getRow()) &&
                        (cars[i].getPos().getCol() == cars[j].getPos().getCol()) &&
                        (j != i) &&
                        cars[i].getName() != "Tank" &&
                        cars[j].getName() == "Tank") {
                    cars[i].setCrashed(true);
                } else if ((cars[i].getPos().getRow() == cars[j].getPos().getRow()) &&
                        (cars[i].getPos().getCol() == cars[j].getPos().getCol()) &&
                        (j != i) &&
                        cars[i].getName() == "Tank" &&
                        cars[j].getName() != "Tank") {
                    cars[j].setCrashed(true);
                }
            }
        }
    }

        @Override
        public String toString () {
            return "T";
        }
    }

