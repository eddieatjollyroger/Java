package org.academiadecodigo.carcrash.cars;

public class Missile extends Car{



    public Missile(String missile) {
        this.name = name;

    }



    @Override
    public void moveCars(int speed) {

        super.moveCars(speed);
    }





    @Override
    public String toString () {
        return "M";
    }
}
