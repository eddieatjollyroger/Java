package org.academiadecodigo.carcrash.cars;

public class CarFactory {
    private CarFactory carFactory;

    public static Car getNewCar() {
        int randomNumber = (int) (Math.random() * (101));
        if (randomNumber < 50) {

            Roadster roadster = new Roadster("Roadster");
            return roadster;
        }
        NissanPuke nissan = new NissanPuke("Nissan");
        return nissan;
    }
}
