package org.academiadecodigo.carcrash.cars;

public class CarFactory {
    private CarFactory carFactory;

    public static Car getNewCar() {
        int randomNumber = (int) (Math.random() * (101));
        if (randomNumber < 25) {

            Roadster roadster = new Roadster("Roadster");
            return roadster;
        }
        else if(randomNumber > 24 && randomNumber < 75) {
            NissanPuke nissan = new NissanPuke("Nissan");
            return nissan;
        }
        else
        {

            Tank tank = new Tank("Tank");
            return tank;
        }
    }
}
