package org.academiadecodigo.carcrash.cars;

import org.academiadecodigo.carcrash.field.Position;

abstract public class Car {

    protected String name;
    /** The position of the car on the grid */
    private Position pos;
    private boolean crashed = false;
    private int goingUp;
    private String direction;

    public Car() {
        this.pos = new Position();
        this.goingUp = 0;
        this.direction = direction;
    }

    public void setDirection(String direction){
        this.direction = direction;
    }

    public String getDirection() {
        return direction;
    }

    public String getName() {
        return name;
    }

    public int getGoingUp() {
        return goingUp;
    }

    public void setGoingUp(int goingUp) {
        this.goingUp = goingUp;
    }

    public Position getPos() {
        return pos;
    }

    public boolean isCrashed() {
        return crashed;
    }

    public void setCrashed(boolean crashed) {
        this.crashed = crashed;
    }
}
