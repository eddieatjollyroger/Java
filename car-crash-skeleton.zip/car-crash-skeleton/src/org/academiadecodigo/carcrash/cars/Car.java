package org.academiadecodigo.carcrash.cars;

import org.academiadecodigo.carcrash.field.Position;

abstract public class Car {

    protected String name;
    /** The position of the car on the grid */
    private Position pos;
    private boolean crashed = false;
    private int goingUp;
    private String direction;

    public Car() {
        this.pos = new Position();
        this.goingUp = 0;
        this.direction = direction;
    }

    public void setDirection(String direction){
        this.direction = direction;
    }

    public String getDirection() {
        return direction;
    }

    public String getName() {
        return name;
    }

    public int getGoingUp() {
        return goingUp;
    }

    public void setGoingUp(int goingUp) {
        this.goingUp = goingUp;
    }

    public Position getPos() {
        return pos;
    }

    public boolean isCrashed() {
        return crashed;
    }

    public void setCrashed(boolean crashed) {
        this.crashed = crashed;
    }

    public void moveCars() {

    }
    public void compareCars(Car[] cars){
            for (int j = 0; j < cars.length; j++) {
                for (int i = 0; i < cars.length; i++) {
                    if ((cars[i].getPos().getRow() == cars[j].getPos().getRow()) &&
                            (cars[i].getPos().getCol() == cars[j].getPos().getCol()) &&
                            (j != i) &&
                            cars[i].getName() != "Tank" &&
                            cars[j].getName() != "Tank") {
                        cars[i].setCrashed(true);
                        cars[j].setCrashed(true);
                    }
                }
            }
        }
    }

