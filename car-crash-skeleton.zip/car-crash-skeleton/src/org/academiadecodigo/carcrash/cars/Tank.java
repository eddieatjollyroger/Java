package org.academiadecodigo.carcrash.cars;

public class Tank extends Car {
    private int counter = 0;

    public Tank(String name) {
        this.name = name;
    }

    @Override
    public void moveCars() {
        super.moveCars();
        if (super.getPos().getCol() > 98) {
            super.getPos().setCol(super.getPos().getCol() - 1);
            counter = 4;
        } else if (super.getPos().getCol() < 2) {
            super.getPos().setCol(super.getPos().getCol() + 1);
            counter = 4;
        } else if (super.getPos().getRow() < 2) {
            super.getPos().setRow(super.getPos().getRow() + 1);
            counter = 4;
        } else if (super.getPos().getRow() > 24) {
            super.getPos().setRow(super.getPos().getRow() - 1);
            counter = 4;
        }
        if (counter < 4) {
            if (super.getDirection() == "up") {
                super.getPos().setRow(super.getPos().getRow() - 1);
                counter++;
            } else if (super.getDirection() == "down") {
                super.getPos().setRow(super.getPos().getRow() + 1);
                counter++;
            } else if (super.getDirection() == "left") {
                super.getPos().setCol(super.getPos().getCol() - 1);
                counter++;
            } else {
                super.getPos().setCol(super.getPos().getCol() + 1);
                counter++;
            }
        }
        if (counter == 4) {
            switch ((int) (Math.random() * (4))) {

                case 0: {                                               //  is up
                    super.getPos().setRow(super.getPos().getRow() - 1);
                    setDirection("up");
                    counter = 0;
                    break;
                }
                case 1: {
                    super.getPos().setRow(super.getPos().getRow() + 1);
                    setDirection("down");
                    counter = 0;
                    break;                                              // is down
                }
                case 2: {                                               // is left
                    super.getPos().setCol(super.getPos().getCol() - 1);
                    setDirection("left");
                    counter = 0;
                    break;
                }
                case 3: {                                               // is right
                    super.getPos().setCol(super.getPos().getCol() + 1);
                    setDirection("right");
                    counter = 0;
                    break;
                }
            }
        }
    }

    @Override
    public void compareCars(Car[] cars) {

        for (int j = 0; j < cars.length; j++) {
            for (int i = 0; i < cars.length; i++) {
                if ((cars[i].getPos().getRow() == cars[j].getPos().getRow()) &&
                        (cars[i].getPos().getCol() == cars[j].getPos().getCol()) &&
                        (j != i) &&
                        cars[i].getName() == "Tank" &&
                        cars[j].getName() == "Tank") {
                    cars[i].setCrashed(true);
                    cars[j].setCrashed(true);
                } else if ((cars[i].getPos().getRow() == cars[j].getPos().getRow()) &&
                        (cars[i].getPos().getCol() == cars[j].getPos().getCol()) &&
                        (j != i) &&
                        cars[i].getName() != "Tank" &&
                        cars[j].getName() == "Tank") {
                    cars[i].setCrashed(true);
                } else if ((cars[i].getPos().getRow() == cars[j].getPos().getRow()) &&
                        (cars[i].getPos().getCol() == cars[j].getPos().getCol()) &&
                        (j != i) &&
                        cars[i].getName() == "Tank" &&
                        cars[j].getName() != "Tank") {
                    cars[j].setCrashed(true);
                }
            }
        }
    }
        // @Override
        // public void setCrashed(boolean crashed) {
        //}

        @Override
        public String toString () {
            return "T";
        }
    }

