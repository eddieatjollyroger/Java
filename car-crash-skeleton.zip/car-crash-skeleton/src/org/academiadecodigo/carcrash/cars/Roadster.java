package org.academiadecodigo.carcrash.cars;
import org.academiadecodigo.carcrash.cars.Car;


public class Roadster extends Car {

    public Roadster(String name){
    this.name = name;
    }


    @Override
    public String toString() {
        return "R";
    }
}


