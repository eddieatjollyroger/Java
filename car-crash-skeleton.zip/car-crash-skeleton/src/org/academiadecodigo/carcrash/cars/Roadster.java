package org.academiadecodigo.carcrash.cars;


public class Roadster extends Car {

    public Roadster(String name){
    this.name = name;
    }


    @Override
    public void moveCars() {
        int counter = 0;
        if (super.getPos().getCol() > 96) {
            super.getPos().setCol(super.getPos().getCol() - 2);
            counter++;
        } else if (super.getPos().getCol() < 4) {
            super.getPos().setCol(super.getPos().getCol() + 2);
            counter++;
        } else if (super.getPos().getRow() < 4) {
            super.getPos().setRow(super.getPos().getRow() + 2);
            counter++;
        } else if (super.getPos().getRow() > 22) {
            super.getPos().setRow(super.getPos().getRow() - 2);
            counter++;
        }
        if (counter == 0) {
            switch ((int) (Math.random() * (4))) {

                case 0: {                                               //  is up
                    super.getPos().setRow(super.getPos().getRow() - 1);
                    super.getPos().setRow(super.getPos().getRow() - 1);
                    break;
                }
                case 1: {
                    super.getPos().setRow(super.getPos().getRow() + 1);
                    super.getPos().setRow(super.getPos().getRow() + 1);
                    break;                                              // is down
                }
                case 2: {                                               // is left
                    super.getPos().setCol(super.getPos().getCol() - 1);
                    super.getPos().setCol(super.getPos().getCol() - 1);
                    break;
                }
                case 3: {                                               // is right
                    super.getPos().setCol(super.getPos().getCol() + 1);
                    super.getPos().setCol(super.getPos().getCol() + 1);
                    break;
                }
            }
        }
    }

    // @Override
   // public void setCrashed(boolean crashed) {
   // }

    @Override
    public String toString() {
        return "R";
    }
}


