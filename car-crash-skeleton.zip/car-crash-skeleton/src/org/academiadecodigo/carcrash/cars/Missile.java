package org.academiadecodigo.carcrash.cars;

import java.awt.print.PrinterAbortException;

public class Missile {
    private Tank tank;

    public Missile() {
        this.tank = tank;
    }


}
