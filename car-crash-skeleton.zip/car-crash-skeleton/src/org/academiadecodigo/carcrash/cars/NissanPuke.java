package org.academiadecodigo.carcrash.cars;

public class NissanPuke extends Car {
    public NissanPuke(String name){
this.name = name;
    }

    @Override
    public String toString() {
        return "N";
    }
}
