package org.academiadecodigo.carcrash;

import org.academiadecodigo.carcrash.cars.Car;
import org.academiadecodigo.carcrash.cars.CarFactory;
import org.academiadecodigo.carcrash.cars.NissanPuke;
import org.academiadecodigo.carcrash.cars.Roadster;
import org.academiadecodigo.carcrash.field.Field;
import org.academiadecodigo.carcrash.field.Position;

public class Game {

    public static final int MANUFACTURED_CARS = 20;

    /**
     * Container of Cars
     */
    private Car[] cars;
    private Position[] positions;
    /**
     * Animation delay
     */
    private int delay;

    public Game(int cols, int rows, int delay) {

        Field.init(cols, rows);
        this.delay = delay;

    }

    /**
     * Creates a bunch of cars and randomly puts them in the field
     */
    public void init() {

        cars = new Car[MANUFACTURED_CARS];
        positions = new Position[MANUFACTURED_CARS];
        for (int i = 0; i < cars.length; i++) {
            cars[i] = CarFactory.getNewCar();
            positions[i] = cars[i].getPos();
        }
        Field.draw(cars);

    }

    /**
     * Starts the animation
     *
     * @throws InterruptedException
     */
    public void start() throws InterruptedException {

        while (true) {

            // Pause for a while
            Thread.sleep(delay);

            // Move all cars
            moveAllCars(cars);

            // Update screen
            Field.draw(cars);

        }

    }

    private void moveAllCars(Car[] cars) {
        for (int j = 0; j < cars.length; j++) {
            int counter = 0;
            if (!cars[j].isCrashed()) {

                if (cars[j].getName() == "Nissan") {
                    if (cars[j].getPos().getRow() == 0 &&
                            cars[j].getPos().getCol() == 99 ||
                            cars[j].getPos().getCol() == 99 &&
                                    cars[j].getPos().getRow() == 24) {

                        cars[j].getPos().setCol(0);

                    }
                    if (cars[j].getPos().getRow() == 0) {
                        cars[j].getPos().setCol(cars[j].getPos().getCol() + 1);
                        cars[j].setGoingUp(0);
                    } else if (cars[j].getPos().getRow() >= 24) {
                        cars[j].getPos().setCol(cars[j].getPos().getCol() + 1);
                        cars[j].setGoingUp(1);
                    }
                    if (cars[j].getGoingUp() == 0) {
                        int numberRow = cars[j].getPos().getRow() + 1;
                        cars[j].getPos().setRow(numberRow);
                    } else if (cars[j].getGoingUp() == 1) {
                        int numberRow = cars[j].getPos().getRow() - 1;
                        cars[j].getPos().setRow(numberRow);
                    }

                } else if (cars[j].getName() == "Roadster") {
                    if (cars[j].getPos().getCol() > 96) {
                        cars[j].getPos().setCol(cars[j].getPos().getCol() - 2);
                        counter++;
                    } else if (cars[j].getPos().getCol() < 4) {
                        cars[j].getPos().setCol(cars[j].getPos().getCol() + 2);
                        counter++;
                    } else if (cars[j].getPos().getRow() < 4) {
                        cars[j].getPos().setRow(cars[j].getPos().getRow() + 2);
                        counter++;
                    } else if (cars[j].getPos().getRow() > 22) {
                        cars[j].getPos().setRow(cars[j].getPos().getRow() - 2);
                        counter++;
                    }
                    if (counter == 0) {
                        switch ((int) (Math.random() * (4))) {

                            case 0: {                                               //  is up
                                cars[j].getPos().setRow(cars[j].getPos().getRow() - 1);
                                cars[j].getPos().setRow(cars[j].getPos().getRow() - 1);
                                break;
                            }
                            case 1: {
                                cars[j].getPos().setRow(cars[j].getPos().getRow() + 1);
                                cars[j].getPos().setRow(cars[j].getPos().getRow() + 1);
                                break;                                              // is down
                            }
                            case 2: {                                               // is left
                                cars[j].getPos().setCol(cars[j].getPos().getCol() - 1);
                                cars[j].getPos().setCol(cars[j].getPos().getCol() - 1);
                                break;
                            }
                            case 3: {                                               // is right
                                cars[j].getPos().setCol(cars[j].getPos().getCol() + 1);
                                cars[j].getPos().setCol(cars[j].getPos().getCol() + 1);
                                break;
                            }
                        }
                    }
                }
                    for (int i = 0; i < cars.length; i++) {
                        if ((cars[i].getPos().getRow() == cars[j].getPos().getRow()) &&
                                (cars[i].getPos().getCol() == cars[j].getPos().getCol()) &&
                                (j != i)) {
                            cars[i].setCrashed(true);
                            cars[j].setCrashed(true);

                        }
                    }
                }
            }
        }

    }
