package org.academiadecodigo.maindalorians;

public class SniperE1337 {
    public static void main(String[] args) {
        Game game = new Game();
        game.start();
    }
}
