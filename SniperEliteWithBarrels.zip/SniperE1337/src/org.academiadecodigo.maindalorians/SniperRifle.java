package org.academiadecodigo.maindalorians;

import org.academiadecodigo.maindalorians.enemies.Destroyable;
import org.academiadecodigo.maindalorians.enemies.Enemy;

public class SniperRifle {
    private int bulletDamage;

    public void shoot(Destroyable destroyable) {
        int counter = 0;
        while (!destroyable.isDestroyed()) {
            bulletDamage = (int) ((Math.random() * 100) + 1);
            destroyable.hit(bulletDamage);
            counter++;
        }
        System.out.println("Killed enemy in " + counter + " shots");
        System.out.println("________________________");
    }
}
