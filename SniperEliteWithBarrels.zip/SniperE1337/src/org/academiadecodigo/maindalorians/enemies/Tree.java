package org.academiadecodigo.maindalorians.enemies;

public class Tree extends GameObject{
   @Override
   public String getMessage(){
       return "boas guy i tree";
   }
}
