package org.academiadecodigo.maindalorians.enemies;

public abstract class GameObject{

    public String getMessage() {
        return "boas i game object";
    }
}
