package org.academiadecodigo.maindalorians.enemies;

public interface Destroyable {

    public abstract void hit(int damage);

    public abstract boolean isDestroyed();
}


