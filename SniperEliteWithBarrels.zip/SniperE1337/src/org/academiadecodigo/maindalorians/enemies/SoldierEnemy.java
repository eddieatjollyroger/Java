package org.academiadecodigo.maindalorians.enemies;

public class SoldierEnemy extends Enemy{

public void hit(){

}

}
